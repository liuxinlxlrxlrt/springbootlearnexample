package com.mayikt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootMybaitsApplicationTests {

	@Test
	void contextLoads() {
	}

}
